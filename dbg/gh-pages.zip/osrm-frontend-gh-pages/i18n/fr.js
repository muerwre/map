module.exports = {
  name: 'Français',
  key: 'fr',
  'Open in editor': 'Ouvrir dans l\'éditeur',
  'Open in JOSM': 'Ouvrir dans JOSM',
  'Open in Debug Map': 'Ouvrir dans Debug Map',
  'Open in Mapillary': 'Ouvrir dans Mapillary',
  'Select language': 'Choisir la langue',
  'Start - press enter to drop marker': 'Point de départ',
  'End - press enter to drop marker': 'Étape intermédiaire',
  'Via point - press enter to drop marker': 'Point d\'arrivée'
};
