module.exports = {
  name: 'English',
  key: 'en',
  'Open in Debug Map': 'Open in Debug Map',
  'Open in Mapillary': 'Open in Mapillary',
  'Open in editor': 'Open in editor',
  'Open in JOSM': 'Open in JOSM',
  'Select language': 'Select language',
  'Start - press enter to drop marker': 'Start - press enter to drop marker',
  'End - press enter to drop marker': 'End - press enter to drop marker',
  'Via point - press enter to drop marker': 'Via point - press enter to drop marker'
};
