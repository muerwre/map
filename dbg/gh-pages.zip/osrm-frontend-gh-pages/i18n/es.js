module.exports = {
  name: 'Español',
  key: 'es',
  'Open in Debug Map': 'Abrir en mapa depuración',
  'Open in Mapillary': 'Abrir en Mapillary',
  'Open in editor': 'Abrir en editor',
  'Open in JOSM': 'Abrir en JOSM',
  'Select language': 'Seleccionar idioma',
  'Start - press enter to drop marker': 'Incio - presione enter para colocar el marcador',
  'End - press enter to drop marker': 'Fin - presione enter para colocar el marcador',
  'Via point - press enter to drop marker': 'Punto en la vía - presione enter para colocar un marcador'
};
